const {module, inject} = angular.mock;
const {spy} = sinon;
describe('Filters: d2Services', () => {

    beforeEach(module('d2Services'));

/*TODO: Add services for dhis2.angular.services */


